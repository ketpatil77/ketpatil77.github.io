import { motion, useReducedMotion } from 'framer-motion';
import { ArrowUpRight, CheckCircle2, FileText, Sparkles } from 'lucide-react';
import { AnimatedText } from '@/components/AnimatedText';
import { motionTokens } from '@/lib/motion';
import { publicationsConfig } from '@/config';

export function Publications() {
  const shouldReduceMotion = useReducedMotion();

  if (publicationsConfig.items.length === 0) return null;

  return (
    <section id="publications" className="section-shell relative overflow-hidden">
      <div
        className="pointer-events-none absolute left-1/4 top-0 h-[360px] w-[360px] -translate-y-1/3 rounded-full opacity-[0.05]"
        style={{ background: 'radial-gradient(circle, var(--violet), transparent 65%)', filter: 'blur(90px)' }}
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute bottom-0 right-0 h-[420px] w-[420px] translate-x-1/4 translate-y-1/4 rounded-full opacity-[0.05]"
        style={{ background: 'radial-gradient(circle, var(--cyan-full), transparent 65%)', filter: 'blur(100px)' }}
        aria-hidden="true"
      />

      <div className="container-large relative z-10">
        <div className="section-header mb-8 sm:mb-10">
          <span className="section-eyebrow">
            <Sparkles className="h-4 w-4" aria-hidden="true" />
            {publicationsConfig.label}
          </span>
          <AnimatedText
            el="h2"
            text={publicationsConfig.heading}
            type="words"
            className="section-title max-w-4xl text-balance"
          />
          <p className="section-copy type-body max-w-3xl">{publicationsConfig.description}</p>
        </div>

        <div className="grid gap-6 xl:grid-cols-[0.86fr_1.14fr] xl:items-start">
          <motion.aside
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={shouldReduceMotion ? { duration: 0 } : motionTokens.spring.soft}
            className="surface-card h-fit p-5 sm:p-6 xl:sticky xl:top-28"
          >
            <p className="type-meta text-[0.66rem] font-bold text-[var(--cyan-full)]">Research Snapshot</p>
            <h3 className="type-heading mt-3 text-[1.4rem] font-bold leading-tight text-[var(--text-100)] sm:text-[1.7rem]">
              Two peer-reviewed AI/ML papers published in 2026.
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-[var(--text-300)] sm:text-[0.95rem]">
              The strongest gap between the resume and site was formal research credibility. This section closes that gap
              with publication-grade proof, concrete metrics, and direct paper access.
            </p>

            <div className="proof-ribbon mt-5">
              {publicationsConfig.highlights.map((metric) => (
                <div key={metric.label} className="proof-ribbon-item">
                  <p className="proof-ribbon-value">{metric.value}</p>
                  <p className="proof-ribbon-label">{metric.label}</p>
                </div>
              ))}
            </div>

            <div className="mt-6">
              <p className="type-meta text-[0.66rem] font-bold text-[var(--text-400)]">Research Themes</p>
              <div className="mt-3 space-y-3">
                {publicationsConfig.themes.map((theme) => (
                  <div
                    key={theme}
                    className="flex gap-3 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-4 py-3"
                  >
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--cyan-full)]" aria-hidden="true" />
                    <p className="text-sm leading-relaxed text-[var(--text-200)]">{theme}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.aside>

          <div className="space-y-5">
            {publicationsConfig.items.map((item, index) => (
              <motion.article
                key={item.paperId}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={
                  shouldReduceMotion
                    ? { duration: 0 }
                    : { duration: motionTokens.duration.base, ease: motionTokens.ease.standard, delay: index * 0.05 }
                }
                className="glass-card relative overflow-hidden rounded-[1.4rem] p-5 sm:p-6"
              >
                <div
                  className="absolute inset-x-0 top-0 h-px"
                  style={{ background: 'linear-gradient(90deg, transparent, var(--border-accent) 50%, transparent)' }}
                  aria-hidden="true"
                />

                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap gap-2">
                      <span className="tech-tag">{item.issue}</span>
                      <span className="tech-tag">{item.publishedOn}</span>
                      <span className="tech-tag">IF {item.impactFactor}</span>
                      <span className="tech-tag">{item.paperId}</span>
                    </div>

                    <h3 className="type-heading mt-3 text-[1.2rem] font-bold leading-tight text-[var(--text-100)] sm:text-[1.45rem]">
                      {item.title}
                    </h3>
                    <p className="mt-3 text-sm font-medium text-[var(--text-200)]">{item.journal}</p>
                    <p className="mt-1 text-sm leading-relaxed text-[var(--text-300)]">{item.authors}</p>
                  </div>

                  <a
                    href={item.pdfHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-outline focus-ring inline-flex w-full justify-center gap-2 sm:w-auto"
                  >
                    <FileText className="h-4 w-4" aria-hidden="true" />
                    Read Paper
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                </div>

                <p className="mt-5 text-sm leading-relaxed text-[var(--text-200)] sm:text-[0.95rem]">
                  {item.summary}
                </p>

                <div className="mt-6 grid gap-5 lg:grid-cols-[1.06fr_0.94fr]">
                  <section>
                    <p className="type-meta text-[0.66rem] font-bold text-[var(--text-400)]">Key Contributions</p>
                    <ul className="mt-3 space-y-3">
                      {item.contributions.map((contribution) => (
                        <li key={contribution} className="flex gap-3">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--cyan-full)]" aria-hidden="true" />
                          <span className="text-sm leading-relaxed text-[var(--text-200)]">{contribution}</span>
                        </li>
                      ))}
                    </ul>
                  </section>

                  <div className="space-y-5 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-4">
                    <section>
                      <p className="type-meta text-[0.66rem] font-bold text-[var(--text-400)]">Proof Points</p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {item.metrics.map((metric) => (
                          <span key={`${item.paperId}-${metric}`} className="tech-tag" style={{ background: 'var(--bg-surface)' }}>
                            {metric}
                          </span>
                        ))}
                      </div>
                    </section>

                    <section>
                      <p className="type-meta text-[0.66rem] font-bold text-[var(--text-400)]">Focus Areas</p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {item.focusAreas.map((focusArea) => (
                          <span
                            key={`${item.paperId}-${focusArea}`}
                            className="rounded-full border border-[var(--border-subtle)] px-3 py-1 text-[0.68rem] font-medium text-[var(--text-200)]"
                            style={{ background: 'var(--bg-surface)' }}
                          >
                            {focusArea}
                          </span>
                        ))}
                      </div>
                    </section>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
